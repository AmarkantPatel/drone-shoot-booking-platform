from django.apps import AppConfig


class DroneBookingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'drone_booking'
